export default class Edge {
    constructor(p1, p2) {
        this.p1 = p1;
        this.p2 = p2;
    }
}