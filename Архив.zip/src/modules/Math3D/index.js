import Math3D from "./Math3D";
export {Point,Edge,Light,Polygon} from './entities';
export {Cube,Ellipsoid,Sphere,Tor,Figure,OneSheetedHyperboloid,EllipticalCylinder,EllipticalParaboloid,
    ParabolicCylinder,TwoSheetedHyperboloid, HyperbolicCylinder, HyperbolicParaboloid, Cylinder, LegoBrick, Cone } from './figures';
export default Math3D;