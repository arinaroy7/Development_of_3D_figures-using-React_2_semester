import Cube from './Cube';
import Ellipsoid from './Ellipsoid';
import Sphere from './Sphere';
import Tor from './Tor';
import Figure from './Figure'
import Cylinder from "./Сylinder";
import OneSheetedHyperboloid from "./OneSheetedHyperboloid";
import EllipticalParaboloid from "./EllipticalParaboloid";
import EllipticalCylinder from "./EllipticalCylinder";
import ParabolicCylinder from "./ParabolicCylinder";
import TwoSheetedHyperboloid from "./TwoSheetedHyperboloid";
import HyperbolicCylinder from "./HyperbolicCylinder";
import HyperbolicParaboloid from "./HyperbolicParaboloid";
import LegoBrick from "./LegoBrick";
import Cone from "./Cone";
export {Cube,Ellipsoid,Sphere,Tor,Figure,OneSheetedHyperboloid,EllipticalCylinder,EllipticalParaboloid,
ParabolicCylinder,TwoSheetedHyperboloid, HyperbolicCylinder, HyperbolicParaboloid, Cylinder, LegoBrick, Cone};