import Figure from '../figures/Figure';
import {Edge,Polygon,Point} from '../entities'
export default class Sphere extends Figure {
    constructor(r = 10, count = 20, color = 'blue') {
        super({});
        //about points
        const points = [];
        for (let i = 0; i <= count; i++) {
            const T = Math.PI / count * i;//
            for (let j = 0; j < count; j++) {
                const p = 2 * Math.PI / count * j;
                points.push(new Point(
                    r * Math.sin(T) * Math.cos(p),
                    r * Math.cos(T),
                    r * Math.sin(T) * Math.sin(p),
                ))
            }
        }
        //about edges;
        const edges = [];
        for (let i = 0; i < points.length; i++) {
            if (points[i + 1]) {
                if ((i + 1) % count === 0) {
                    edges.push(new Edge(i, i + 1 - count))//

                } else {
                    edges.push(new Edge(i, i + 1))
                }
            }
            if (points[i + count]) {
                edges.push(new Edge(i, i + count))
            }
        }

        //about polygons
        const polygons = [];
        for (let i = 0; i < points.length; i++) {
            if (i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/20))%2===0 && i%2===0 ) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#ffffff'));
            }
            else if(i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/20))%2===0 && i%2!==0 ) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#000000'));
            }
            else if(i + 1 + count < points.length && (i + 1) % count !== 0 &&  (~~(i/20))%2!==0 && i%2===0 ) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#000000'));
            }
            else if(i + 1 + count < points.length && (i + 1) % count !== 0 &&  (~~(i/20))%2!==0 && i%2!==0 ) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#ffffff'));
            }
            else if (i + count < points.length && (i + 1) % count === 0 &&(i+1)%(2*count)===0) {
                polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'#ffffff'))
            }
            else if (i + count < points.length && (i + 1) % count === 0&&(i+1)%(2*count)!==0) {
                polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'#000000'))
            }
        }

        this.polygons = polygons;
        this.points = points;
        this.edges = edges;

    } //Дз для каждой выбранной фигуры, показывать настройки.
}