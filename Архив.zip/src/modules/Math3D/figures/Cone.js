import {Edge,Point,Polygon} from '../entities';
import Figure from '../figures/Figure';
export default class Cone extends Figure {
    constructor(a = 4, b = 4, c = 4, count = 10){
        super({});
        
        // Точки
        const points = [];
        // Боковая часть
        const T = 2 * Math.PI / count;
        for (let i = -Math.PI; i <= Math.PI; i += T) {
            for (let j = 0; j < 2 * Math.PI; j += T) {
                points.push(new Point(
                    a * i * Math.cos(j),
                    c * i,
                    Math.sin(j) * b * i
                ));
            }
        }

        // Основания
        for (let i = -Math.PI; i <= Math.PI; i += T) {
            for (let j = 0; j < 2 * Math.PI; j += T) {
                points.push(new Point(
                    a * i * Math.cos(j),
                    c * Math.PI,
                    Math.sin(j) * b * i
                ));
            }
        }
        for (let i = -Math.PI; i <= Math.PI; i += T) {
            for (let j = 0; j < 2 * Math.PI; j += T) {
                points.push(new Point(
                    a * i * Math.cos(j), -c * Math.PI,
                    Math.sin(j) * b * i
                ));
            }
        }

        // Грани
        const edges = [];
        for (let i = 0; i < points.length; i++) {
            //вдоль
            if (i + 1 < points.length && (i + 1) % count !== 0) {
                edges.push(new Edge(
                    i,
                    i + 1
                ));
            } else if ((i + 1) % count === 0) {
                edges.push(new Edge(
                    i,
                    i + 1 - count
                ));
            }
            //поперек
            if (i < points.length - count) {
                edges.push(new Edge(
                    i,
                    i + count
                ));
            }
        }

        const polygons = [];//Пополам горизонт
        for (let i = 0; i < points.length; i++) {
            if (i + 1 + count < points.length && (i + 1) % count !== 0 && i<50) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#ff0107'));
            }
            else if (i + 1 + count < points.length && (i + 1) % count !== 0 && i>=50) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'#ff9999'));}
            else if (i + count < points.length && (i + 1) % count === 0 && i<50) {
                polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'#ff0107'))
            }
            else if (i + count < points.length && (i + 1) % count === 0 && i>50) {
                polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'#ff9999'))
            }
        }
        // const polygons = []//Вдоль
        // for (let i = 0; i < points.length; i++) {
        //     if (i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/(count/2)))%2!==0 && i<=50) {
        //         polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'000000'));
        //     }
        //     else if (i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/(count/2)))%2!==0 && i>50) {
        //         polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'ff0000'));
        //     }
        //     else if (i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/(count/2)))%2===0 && i>=50 ) {
        //         polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'000000'));
        //     }
        //     else if (i + 1 + count < points.length && (i + 1) % count !== 0 && (~~(i/(count/2)))%2===0 && i<50 ) {
        //         polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count],'ff0000'));
        //     }
        //     else if (i + count < points.length && (i + 1) % count === 0 && i<=50) {
        //         polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'000000'));
        //     }
        //     else if (i + count < points.length && (i + 1) % count === 0 && i>50) {
        //         polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count],'ff0000'));
        //     }
        // }

        this.points = points;
        this.edges = edges;
        this.polygons = polygons;
    }
}