import {Edge,Point,Polygon} from '../entities';
import Figure from '../figures/Figure';
export default class Ellipsoid extends Figure {
    constructor(a = 10, b = 20, c = 30, count = 20, color = 'blue') {
        super({});
        // about points
        const points = [];
        for (let i = 0; i <= count; i++) {
            const T = ((2 * Math.PI) / count) * i;
            for (let j = 0; j < count; j++) {
                const p = ((2 * Math.PI) / count) * j;
                points.push(
                    new Point(
                        a * Math.sin(T) * Math.cos(p),
                        c * Math.cos(T),
                        b * Math.sin(T) * Math.sin(p))
                );
            }
        }
        //about edges
        const edges = [];
        for (let i = 0; i <= points.length; i++) {
            if (points[i + 1]) {
                if (((i + 1) % count) === 0) {
                    edges.push(new Edge(i, i + 1 - count));
                } else {
                    edges.push(new Edge(i, i + 1));
                }
            }
            if (points[i + count]) {
                edges.push(new Edge(i, i + count));
            }

        }
        //about polygons
        const polygons = [];
        for (let i = 0; i < points.length; i++) {
            if (i + 1 + count < points.length && (i + 1) % count !== 0) {
                polygons.push(new Polygon([i, i + 1, i + 1 + count, i + count]));
            } else if (i + count < points.length && (i + 1) % count === 0) {
                polygons.push(new Polygon([i, i + 1 - count, i + 1, i + count]))
            }
        }

        this.polygons = polygons;
        this.points = points;
        this.edges = edges;

    }
}