import Graph from './Graph';

export default function useGraph(render = () => { }) {
    window.requestAnimFrame = (function () {
        return window.requestAnimationFrame ||
            window.webkit.requestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            }
    })();

    let FPS = 0;
    let outFPS = 0;
    let lastTimesStamp = Date.now();
    const animLoop = () => {
        FPS++;
        const timestamp = Date.now();
        if (timestamp - lastTimesStamp >= 1000) {
            outFPS = FPS;
            FPS = 0;
            lastTimesStamp = timestamp;
        }
        render(outFPS);
        window.requestAnimationFrame(animLoop);
    }
    return (params) => {
        animLoop();
        return new Graph(params);
    }
}