﻿export default class Graph {
    constructor({ id, width = 500, height = 500, WIN, callbacks }) {
        this.canvas = document.getElementById(id);
        this.context = this.canvas.getContext('2d');
        this.canvas.width = width;
        this.canvas.height = height;
        this.canvasV = document.createElement('canvas');
        this.canvasV.width = width;
        this.canvasV.height = height;
        this.contextV = this.canvasV.getContext('2d');
        this.WIN = WIN;
        const { wheel, mouseup, mousedown, mousemove, mouseleave } = callbacks;

        this.canvas.addEventListener('wheel', wheel);
        this.canvas.addEventListener('mousedown', mousedown);
        this.canvas.addEventListener('mouseup', mouseup);
        this.canvas.addEventListener('mousemove', mousemove);
        this.canvas.addEventListener('mouseleave', mouseleave);
    }

    render() {
        this.context.drawImage(this.canvasV, 0, 0);
    }

    xs(x) {
        return (x - this.WIN.LEFT) * this.canvas.width / this.WIN.WIDTH
    }

    ys(y) {
        return (this.WIN.HEIGHT + this.WIN.BOTTOM - y) * this.canvas.height / this.WIN.HEIGHT;
    }

    sx(x) {
        return x * this.WIN.WIDTH / this.canvas.width;
    }

    sy(y) {
        return -y * this.WIN.HEIGHT / this.canvas.height;
    }

    clear() {
        this.contextV.fillStyle = '#fafafa';
        this.contextV.fillRect(0, 0, this.canvasV.width, this.canvasV.height);
    }

    line(x1, y1, x2, y2, color = '#000', width = 1, isDashed = false) {
        this.contextV.beginPath();
        this.contextV.lineWidth = width;
        if (isDashed) {
            this.contextV.setLineDash([10, 10]);
        } else {
            this.contextV.setLineDash([]);
        }
        this.contextV.strokeStyle = color;
        this.contextV.moveTo(this.xs(x1), this.ys(y1));
        this.contextV.lineTo(this.xs(x2), this.ys(y2));
        this.contextV.stroke();
        this.contextV.closePath();
        this.contextV.setLineDash([]);
    }

    point(x, y, color = '#1a2b3c', size = 1) {
        this.contextV.beginPath();
        this.contextV.strokeStyle = color;
        this.contextV.fillStyle = color;
        this.contextV.arc(this.xs(x), this.ys(y), size, 0, 2 * Math.PI);
        this.contextV.fill();
        this.contextV.stroke();
        this.contextV.closePath();
    }

    text(x, y, text, color = "black", font = "12px sans-serif", align = "center") {
        this.contextV.font = font;
        this.contextV.fillStyle = color;
        this.contextV.textAlign = align;
        this.contextV.fillText(text, this.xs(x), this.ys(y));
    }

    polygon(points, color = 'blue') {

        this.contextV.beginPath();
        this.contextV.fillStyle = color;
        this.contextV.moveTo(
            this.xs(points[0].x),
            this.ys(points[0].y));
        for (let i = 1; i < points.length; i++) {
            this.contextV.lineTo(
                this.xs(points[i].x),
                this.ys(points[i].y));
        }
        this.contextV.fill();
        this.contextV.closePath();

    }
}