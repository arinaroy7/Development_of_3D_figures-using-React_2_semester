import React from 'react';
import {useState} from 'react';
import Header from "./components/Header/Header";
import Calculator from './components/Calculator/Calculator';
import Graph2DComponent from "./components/Graph2D/Graph2DComponent";
import Graph3D from "./components/Graph3D/Graph3D";
import './App.css';

const App = () => {
    const [showComponent, setShowComponent] = useState(`Graph3D`);
    return (<div>
            <Header showComponent={setShowComponent}/>
            {showComponent === 'Calculator' ? <Calculator/> :
                showComponent === 'Graph2D' ? <Graph2DComponent/> :
                    showComponent === 'Graph3D' ? <Graph3D/> :
                        <></>

            }
        </div>
    )
}
export default App
