import { useState, useCallback } from 'react';
import {
    Cube, Ellipsoid, Sphere, Tor, EllipticalParaboloid, EllipticalCylinder, OneSheetedHyperboloid,
    TwoSheetedHyperboloid, ParabolicCylinder, HyperbolicCylinder, HyperbolicParaboloid, Cylinder, LegoBrick, Cone
} from '../../../modules/Math3D'
import MyCheckBox from "../../components/MyCheckBox/MyCheckBox";

const Graph3DUI = ({ 
    show, 
    updateVarPoints, 
    updateVarPolygons, 
    updateVarEdges, 
    updateScene 
}) => {
    const [showPanel, setShowPanel] = useState(false);
    const figures = {
        Cube: new Cube(),
        Sphere: new Sphere(),
        Tor: new Tor(),
        Ellipsoid: new Ellipsoid(),
        EllipticalParaboloid: new EllipticalParaboloid(),
        EllipticalCylinder: new EllipticalCylinder(),
        OneSheetedHyperboloid: new OneSheetedHyperboloid(),
        TwoSheetedHyperboloid: new TwoSheetedHyperboloid(),
        Cylinder: new Cylinder(),
        ParabolicCylinder: new ParabolicCylinder(),
        HyperbolicCylinder: new HyperbolicCylinder(),
        HyperbolicParaboloid: new HyperbolicParaboloid(),
        LegoBrick: new LegoBrick(),
        Cone: new Cone()


    }
    const showHidePanel = useCallback(() => {
        setShowPanel(!showPanel)
    },
        [setShowPanel, showPanel]
    );
    const selectFigure = useCallback((event) => {
        updateScene(figures[event.target.value])
    },
        [updateScene, figures]);
    return (
        <div>
            <button onClick={showHidePanel}>
                {showPanel ? '<-' : '->'}
            </button>
            {showPanel && (<div>
                    <MyCheckBox
                        text='Точки'
                        checked={show.pointCheck}
                        onClick={updateVarPoints}
                    />
                    <MyCheckBox
                        text='Ребра'
                        checked={show.edgCheck}
                        onClick={updateVarEdges}
                    />
                    <MyCheckBox
                        text='Полигоны'
                        checked={show.plgnCheck}
                        onClick={updateVarPolygons}
                    />
                </div>)
            }
            <div>
                <select onChange={selectFigure}>
                    {Object.keys(figures).map((key, index) => (
                        <option
                            key={index}
                            className="figur"
                            value={key}>{key}</option>

                    ))}
                </select>
            </div>
        </div>
    )
}
export default Graph3DUI;